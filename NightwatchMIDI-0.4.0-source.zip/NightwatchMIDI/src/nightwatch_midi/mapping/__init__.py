"""JSON instrument profile loading."""
